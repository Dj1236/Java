package com.kunal;

import java.util.Arrays;

public class Output {
    public static void main(String[] args) {
        System.out.println(56);
//        Integer num = new Integer(56);
//        System.out.println(num.toString());
//        System.out.println(num);
//        System.out.println("Kunal");
//        System.out.println(Arrays.toString(new int[]{2, 3, 4, 5}));
////
//        String name = null;
//        System.out.println(name);
    }
}
