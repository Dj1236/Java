package com.kunal;

public class Basics {
    public static void main(String[] args) {
//        int a = 10;
//        if (a == 10) {
//            System.out.println("Hello World");
//        }
//        int count = 1;
//        while(count != 5) {
//            System.out.println(count);
//            count++;
//        }

        // for loop
        for(int count = 1; count != 5; count++) {
            System.out.println(count);
        }
    }
}
