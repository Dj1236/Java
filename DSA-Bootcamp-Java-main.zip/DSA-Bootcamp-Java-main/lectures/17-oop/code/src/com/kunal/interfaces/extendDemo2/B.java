package com.kunal.interfaces.extendDemo2;

public interface B{
    void greet();

//    default void fun() {
//        System.out.println("I am in A");
//    }

//    void fun();
}
