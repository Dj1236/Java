package com.kunal.interfaces.extendDemo;

public interface A {
    void fun();
}
