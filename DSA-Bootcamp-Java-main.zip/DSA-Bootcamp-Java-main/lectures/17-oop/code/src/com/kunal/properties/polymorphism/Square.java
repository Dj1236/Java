package com.kunal.properties.polymorphism;

public class Square extends Shapes{
    void area() {
        System.out.println("Area is square of side");
    }
}
