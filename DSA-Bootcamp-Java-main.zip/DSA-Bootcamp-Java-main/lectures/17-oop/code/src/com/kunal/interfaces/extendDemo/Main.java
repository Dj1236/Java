package com.kunal.interfaces.extendDemo;

public class Main implements B{
    @Override
    public void fun() {

    }

    @Override
    public void greet() {

    }
}
