# DSA + Interview preparation bootcamp
- [Join Replit](http://join.replit.com/kunal-kushwaha)
- Subscribe to the [YouTube channel](https://www.youtube.com/KunalKushwaha?sub_confirmation=1)
- [Lectures](https://www.youtube.com/playlist?list=PL9gnSGHSqcnr_DxHsP7AW9ftq0AtAyYqJ)
- [Course website](https://wemakedevs.org/courses/dsa)
- [Assignments](https://github.com/kunal-kushwaha/DSA-Bootcamp-Java/tree/main/assignments) (solutions can be found on LeetCode)
- [Connect with me](http://kunalkushwaha.com)
